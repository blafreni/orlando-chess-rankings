import { Link, createFileRoute } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import { AddPlayerDialog } from "@/components/add-player-dialog";
import { Crosstable } from "@/components/crosstable";
import { EmptyState, LoadingBoard } from "@/components/loading-board";
import { StandingsTable } from "@/components/standings-table";
import { FridaySessionCard, NextGamesCard } from "@/components/tonight-panel";
import { UndoLastGame } from "@/components/undo-last-game";
import { Button } from "@/components/ui/button";
import { getClubSnapshot } from "@/lib/club-api";
import { useClub } from "@/lib/use-club";

export const Route = createFileRoute("/")({
  loader: () => getClubSnapshot(),
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  const { data: snapshot } = useClub(initial);

  if (!snapshot) return <LoadingBoard />;

  const { standings, games, lastGame } = snapshot;

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.14em] text-walnut">
            Club board
          </p>
          <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
            Standings
          </h1>
          <p className="mt-2 max-w-xl text-lg text-muted">
            Club ratings start at 1200. Win, lose, or draw — tap Record a game and the
            board updates for everyone.
          </p>
        </div>
        <div className="no-print flex flex-wrap gap-2">
          <Button asChild>
            <Link to="/record">Record a game</Link>
          </Button>
          <AddPlayerDialog />
          <Button variant="ghost" size="sm" onClick={() => window.print()}>
            <Printer className="size-4" aria-hidden="true" />
            Print
          </Button>
          <UndoLastGame lastGame={lastGame} />
        </div>
      </div>

      <section className="flex flex-col gap-3">
        <div>
          <h2 className="font-display text-2xl font-semibold tracking-tight">Rankings</h2>
          <p className="text-base text-muted">Highest club rating first, form from the last five games.</p>
        </div>
        {standings.length === 0 ? (
          <EmptyState
            title="The club list is empty"
            body="Add the first player, then record a game. No login needed."
            action={<AddPlayerDialog triggerLabel="Add the first player" />}
          />
        ) : (
          <StandingsTable standings={standings} />
        )}
      </section>

      <NextGamesCard games={games} standings={standings} />

      <FridaySessionCard games={games} />

      <Crosstable standings={standings} games={games} />

      <p className="text-base text-muted">
        Need the full roster?{" "}
        <Link to="/players" className="font-semibold text-fg underline underline-offset-4">
          See every player
        </Link>
        .
      </p>
    </div>
  );
}
