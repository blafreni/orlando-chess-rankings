import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import {
  buildClubStats,
  type GameResult,
  type GameRow,
  type PlayerRow,
} from "@/lib/elo";

const nameSchema = z
  .string()
  .trim()
  .min(2, "Name needs at least 2 letters.")
  .max(32, "Name is too long.")
  .regex(
    /^[A-Za-z][A-Za-z .'-()]*$/,
    "Use letters, spaces, hyphens, apostrophes, or parentheses.",
  );

const resultSchema = z.enum(["white", "black", "draw"]);

const dateSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Pick a date.");

type PlayerDb = { id: number; name: string; created_at: string };
type GameDb = {
  id: number;
  white_id: number;
  black_id: number;
  white_name: string;
  black_name: string;
  result: GameResult;
  played_on: string;
  created_at: string;
};

function asText(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  return String(value ?? "");
}

function mapPlayers(rows: PlayerDb[]): PlayerRow[] {
  return rows.map((row) => ({
    id: Number(row.id),
    name: row.name,
    createdAt: asText(row.created_at),
  }));
}

function mapGames(rows: GameDb[]): GameRow[] {
  return rows.map((row) => ({
    id: Number(row.id),
    whiteId: Number(row.white_id),
    blackId: Number(row.black_id),
    whiteName: row.white_name,
    blackName: row.black_name,
    result: row.result,
    playedOn: asText(row.played_on).slice(0, 10),
    createdAt: asText(row.created_at),
  }));
}

async function loadPlayersAndGames() {
  const sql = await getSql();
  const playerRows = await sql<PlayerDb>`
    select id, name, created_at::text as created_at
    from players
    order by name asc
  `;
  const gameRows = await sql<GameDb>`
    select
      g.id,
      g.white_id,
      g.black_id,
      w.name as white_name,
      b.name as black_name,
      g.result,
      g.played_on::text as played_on,
      g.created_at::text as created_at
    from games g
    join players w on w.id = g.white_id
    join players b on b.id = g.black_id
    order by g.played_on asc, g.id asc
  `;
  return { players: mapPlayers(playerRows), games: mapGames(gameRows) };
}

export const getClubSnapshot = createServerFn({ method: "GET" }).handler(
  async () => {
    const { players, games } = await loadPlayersAndGames();
    const { standings, games: annotated } = buildClubStats(players, games);
    const lastGame =
      annotated.reduce<typeof annotated[number] | null>((best, game) => {
        if (!best) return game;
        if (game.createdAt > best.createdAt) return game;
        if (game.createdAt === best.createdAt && game.id > best.id) return game;
        return best;
      }, null) ?? null;
    return {
      players,
      games: annotated,
      standings,
      lastGame,
    };
  },
);

export const addPlayer = createServerFn({ method: "POST" })
  .validator((input: unknown) => z.object({ name: nameSchema }).parse(input))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const existing = await sql<{ id: number }>`
      select id from players where lower(name) = lower(${data.name}) limit 1
    `;
    if (existing.length > 0) {
      throw new Error(`${data.name} is already on the club list.`);
    }
    const inserted = await sql<{ id: number; name: string }>`
      insert into players (name) values (${data.name})
      returning id, name
    `;
    const row = inserted[0];
    if (!row) throw new Error("Could not add player.");
    return { id: Number(row.id), name: row.name };
  });

export const recordGame = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        whiteId: z.number().int().positive(),
        blackId: z.number().int().positive(),
        result: resultSchema,
        playedOn: dateSchema,
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    if (data.whiteId === data.blackId) {
      throw new Error("A player cannot sit on both sides of the board.");
    }
    const sql = await getSql();
    const found = await sql<{ id: number }>`
      select id from players where id = ${data.whiteId} or id = ${data.blackId}
    `;
    if (found.length !== 2) {
      throw new Error("Both players need to be on the club list.");
    }
    const inserted = await sql<{ id: number }>`
      insert into games (white_id, black_id, result, played_on)
      values (${data.whiteId}, ${data.blackId}, ${data.result}, ${data.playedOn}::date)
      returning id
    `;
    const id = inserted[0]?.id;
    if (!id) throw new Error("Could not record the game.");
    const snapshot = await loadPlayersAndGames();
    const { games } = buildClubStats(snapshot.players, snapshot.games);
    const recorded = games.find((game) => game.id === Number(id));
    if (!recorded) throw new Error("Game saved, but could not load the result.");
    return recorded;
  });

export const undoLastGame = createServerFn({ method: "POST" }).handler(
  async () => {
    const sql = await getSql();
    const latest = await sql<{
      id: number;
      white_name: string;
      black_name: string;
      result: GameResult;
    }>`
      select g.id, w.name as white_name, b.name as black_name, g.result
      from games g
      join players w on w.id = g.white_id
      join players b on b.id = g.black_id
      order by g.created_at desc, g.id desc
      limit 1
    `;
    const game = latest[0];
    if (!game) throw new Error("There is no game to undo.");
    await sql`delete from games where id = ${game.id}`;
    return {
      id: Number(game.id),
      whiteName: game.white_name,
      blackName: game.black_name,
      result: game.result,
    };
  },
);
