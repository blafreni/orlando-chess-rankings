# Friday Chess Club

Backup of the Winter Park Friday Chess Club site (standings, ratings, record-a-game).

Snapshot date: 6 September 2026  
Players: 23 · Games: 66 (through Friday 4 September 2026)

## What is in this zip

| Path | What it is |
| --- | --- |
| `src/` | The website (pages, ratings, record-game form) |
| `migrations/` | Database tables and the full club history |
| `data/players.csv` | Roster as a spreadsheet |
| `data/games.csv` | Every recorded game as a spreadsheet |
| `public/` | Favicon and share image |

Even if you never run the site again, open `data/games.csv` and `data/players.csv` in Excel or Google Sheets.

## Run the site on your computer

You need [Node.js 22](https://nodejs.org/) and npm.

```bash
npm install
npm run dev
```

Then open http://localhost:8080

- No login. Anyone with the link can record a game (same as the club spreadsheet).
- Ratings start at 1200. Each game updates Elo (K=32).
- Locally it uses an in-memory Postgres (PGLite). Restarting the server reloads the seeded history from `migrations/`.

## Put it on the internet

1. Create a Postgres database (Neon, Supabase, Railway, etc.).
2. Set `DATABASE_URL` to that connection string.
3. Deploy the folder to [Vercel](https://vercel.com) (or any host that runs a Vite/Nitro Node app).
4. On first deploy, `npm run build` applies the migrations, including the 66 games.

Do not commit a `.env` file with the database password. Set `DATABASE_URL` in the host’s environment settings.

## Daily use

- **Record a game** — White, Black, result, date.
- **Add a player** — names like `Mike (Staff)` are allowed.
- **Undo last game** — removes the most recently saved result.

## Notes

Built with React, TanStack Start, Tailwind, and Postgres. Originally assembled in Grok. This zip is the full source so you can keep running the clubhouse without Grok.
